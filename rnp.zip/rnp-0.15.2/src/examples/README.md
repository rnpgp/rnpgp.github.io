# RNP C API usage samples

This folder includes examples of RNP library usage for developers.

See [Using the RNP C API](/docs/c-usage.adoc) for more details.
