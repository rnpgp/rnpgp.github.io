#!/bin/bash
docker run -it -v $(pwd):/usr/local/rnp centos:7 bash -l

