: "${CORES:=$(nproc --all)}"
export CORES
