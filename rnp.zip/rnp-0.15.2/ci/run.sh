#!/bin/sh
set -eux

ci/main.sh
ci/success.sh
